package com.astrategy.pokemine.controllers;

public class UserCollectionController {

}
