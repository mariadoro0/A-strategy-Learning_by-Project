package com.astrategy.pokemine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokemineApplicationTests {

    @Test
    void contextLoads() {
    }

}
